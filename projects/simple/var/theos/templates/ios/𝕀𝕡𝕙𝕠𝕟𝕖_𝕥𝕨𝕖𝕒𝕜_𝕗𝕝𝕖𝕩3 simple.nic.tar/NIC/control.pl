use File::Copy;
use Cwd;
use File::Copy "cp";

NIC->prompt("HACKNAME", "Name of the hack", {default => ""});

NIC->prompt("USER", "Who made the hack", {default => ""});

NIC->prompt("WAT", "Tweak or hack", {default => ""});

NIC->prompt("NAME", "Your name", {default => ""});

NIC->prompt("DES", "what can the hack or Tweak do", {default => ""});

NIC->prompt("CON", "Were they going contact u from paste link here", {default => ""});

NIC->prompt("APPVERSION", "Version of the hack", {default => ""});

my $default_kill = "SpringBoard";

NIC->variable("KILL_RULE") = "";

my $kill_apps = NIC->prompt("KILL_APPS", "List of applications to terminate upon installation (space-separated, '-' for none)", {default => $default_kill});
if($kill_apps ne "-") {
	NIC->variable("KILL_RULE") = "INSTALL_TARGET_PROCESSES = ".$kill_apps."\n\n";
}
